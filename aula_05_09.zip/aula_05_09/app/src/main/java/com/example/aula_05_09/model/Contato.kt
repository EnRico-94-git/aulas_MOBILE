package edu.curso.agendacontato.model

data class Contato (
    var nome : String = "",
    var email : String = "",
    var telefone : String = ""
)