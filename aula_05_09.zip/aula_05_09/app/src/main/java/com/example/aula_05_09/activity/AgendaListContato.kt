package com.example.aula_05_09.activity

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.ArrayAdapter
import com.example.aula_05_09.databinding.AgendaContatoListaLayoutBinding

class AgendaListContato : Activity() {

    lateinit var binding : AgendaContatoListaLayoutBinding

    override fun  onCreate(bundle : Bundle?) {
        super.onCreate(bundle)
        binding = AgendaContatoListaLayoutBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val textos = arrayOf("Contato 1", "Contato 2", "Contato 3")

        val adaptador = ArrayAdapter<String>(this,
            android.R.layout.simple_list_item_1, textos)

        binding.apply {
            listView.adapter = adaptador
            AgendaContato.setOnClickListener{
                val intent = Intent(this@AgendaListContato, AgendaContatoActivity::class.java)
                startActivity(intent)
            }
        }
    }
}